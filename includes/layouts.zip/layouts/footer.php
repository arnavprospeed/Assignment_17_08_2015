<footer class="footer-style">
  <div class="content container">
    <div class="row">
      <div class="col-sm-4">
        <p>Feel free to contact us on <span class="email"><img src="img/mail.png" alt="Mail us" class="social">&nbspcontact@catalyst.com</span></p>
        <p>All contents &copy; 2015 <a href="http://lynda.com">projectcatalyst.com</a>. All rights reserved.</p>
      </div><!-- col-sm-4 -->
      <div class="col-sm-4 social-container">
        <p>Follow us on:</p>
        <a href="https://twitter.com/arnav_007"><img src="img/twitter.png" class="social"></a>&nbsp&nbsp&nbsp
        <a href="https://twitter.com/arnav_007"><img src="img/facebook.png" class="social"></a>&nbsp&nbsp&nbsp
        <a href="https://google+.com/arnav_007"><img src="img/gplus.png" class="social"></a>
      </div><!-- col-sm-4 social-->
      <div class="col-sm-4">
        <nav class="navbar navbar-inverse" role="navigation">
          <ul class="nav navbar-nav navbar-right navbar-footer">
            <li><a href="terms-of-use.html">Terms of use</a></li>
            <li><a href="#">Privacy policy</a></li>
            <li><a href="about-us.html">Read about us</a></li>
          </ul>
        </nav>
      </div><!-- col-sm-4 -->
    </div><!-- row -->
  </div><!-- content container -->
</footer>

<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap-hover-dropdown.min.js"></script>
<script src="js/script.js"></script>

<!--
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
-->

</body>
</html>
<?php
mysqli_close($connection);
?>
